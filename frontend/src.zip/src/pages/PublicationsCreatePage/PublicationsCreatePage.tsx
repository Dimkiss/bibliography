import { useEffect, useMemo, useState } from 'react';

import { Footer } from '@/components/Footer';
import { Header } from '@/components/Header';
import { useAuth } from '@/features/auth';
import {
  createAdminArticle,
  getAdminPublicationTypes,
  getAdminWorkFormTypes,
  searchAdminArticles,
  searchAdminJournals,
  searchAdminPublishers,
  type AdminOptionDto,
  type ArticleSearchItemDto,
  type PublicationTypeDto,
  type WorkFormTypeDto,
} from '@/shared/api/adminPublications';
import { Button } from '@/shared/ui/Button';
import { OutlineButton } from '@/shared/ui/OutlineButton';
import { TextField } from '@/shared/ui/TextField';
import { navigateTo } from '@/shared/lib/navigation';
import styles from './PublicationsCreatePage.module.css';

type PublicationCategory = 'article' | 'book' | 'conference';
type RelatedRelationType = 'original' | 'translation';

type FormState = {
  workFormType: string;
  publicationTypeFlag: string;
  title: string;
  authorsText: string;
  journal: AdminOptionDto | null;
  publisher: AdminOptionDto | null;
  conferenceName: string;
  doi: string;
  pages: string;
  publicationDate: string;
  year: string;
  abstract: string;
  keywordsInput: string;
  keywords: string[];
  relatedRelationType: RelatedRelationType;
  relatedArticle: ArticleSearchItemDto | null;
  isbn: string;
  tirage: string;
  extentOfWork: string;
  notes: string;
  url: string;
};

type SelectorMode = 'journal' | 'publisher' | 'related' | null;

const INITIAL_FORM: FormState = {
  workFormType: '',
  publicationTypeFlag: '',
  title: '',
  authorsText: '',
  journal: null,
  publisher: null,
  conferenceName: '',
  doi: '',
  pages: '',
  publicationDate: '',
  year: '',
  abstract: '',
  keywordsInput: '',
  keywords: [],
  relatedRelationType: 'original',
  relatedArticle: null,
  isbn: '',
  tirage: '',
  extentOfWork: '',
  notes: '',
  url: '',
};

function getWorkFormLabel(item: WorkFormTypeDto): string {
  return item.label_ru?.trim() || item.label?.trim() || item.value;
}

function resolveCategory(workForm: WorkFormTypeDto | null): PublicationCategory {
  const label = `${workForm?.label_ru ?? ''} ${workForm?.label ?? ''}`.toLowerCase();

  if (label.includes('книж') || label.includes('book') || label.includes('монограф')) {
    return 'book';
  }

  if (label.includes('конферен') || label.includes('conference')) {
    return 'conference';
  }

  return 'article';
}

function normalizeKeywords(value: string): string[] {
  return value
    .split(/[;,\n]/)
    .map((item) => item.trim())
    .filter(Boolean)
    .filter(
      (item, index, array) =>
        array.findIndex((entry) => entry.toLowerCase() === item.toLowerCase()) === index,
    );
}

function formatArticleMeta(item: ArticleSearchItemDto): string {
  return [item.authors, item.journal, item.year, item.doi].filter(Boolean).join(' · ');
}

export function PublicationsCreatePage() {
  const { user, isAuthenticated, isInitializing } = useAuth();

  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [workForms, setWorkForms] = useState<WorkFormTypeDto[]>([]);
  const [publicationTypes, setPublicationTypes] = useState<PublicationTypeDto[]>([]);
  const [isBootLoading, setIsBootLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');

  const [selectorMode, setSelectorMode] = useState<SelectorMode>(null);
  const [selectorQuery, setSelectorQuery] = useState('');
  const [selectorLoading, setSelectorLoading] = useState(false);
  const [journalResults, setJournalResults] = useState<AdminOptionDto[]>([]);
  const [publisherResults, setPublisherResults] = useState<AdminOptionDto[]>([]);
  const [relatedResults, setRelatedResults] = useState<ArticleSearchItemDto[]>([]);

  const isRoleAllowed = Boolean(isAuthenticated && user?.role_id === 5);

  useEffect(() => {
    if (!isInitializing && (!isAuthenticated || user?.role_id !== 5)) {
      navigateTo('/articles');
    }
  }, [isAuthenticated, isInitializing, user?.role_id]);

  useEffect(() => {
    if (!isRoleAllowed) {
      return;
    }

    let isMounted = true;

    async function loadInitialData() {
      setIsBootLoading(true);
      setError('');

      try {
        const workFormItems = await getAdminWorkFormTypes();

        if (!isMounted) {
          return;
        }

        setWorkForms(workFormItems);

        const preferredWorkForm =
          workFormItems.find((item) => item.value === 'J') ??
          workFormItems.find((item) => {
            const label = getWorkFormLabel(item).toLowerCase();
            return label.includes('стат');
          }) ??
          workFormItems[0] ??
          null;

        if (!preferredWorkForm) {
          setPublicationTypes([]);
          return;
        }

        const publicationTypeItems = await getAdminPublicationTypes(preferredWorkForm.value);

        if (!isMounted) {
          return;
        }

        setPublicationTypes(publicationTypeItems);
        setForm((prev) => ({
          ...prev,
          workFormType: preferredWorkForm.value,
          publicationTypeFlag: publicationTypeItems[0]?.value ?? '',
        }));
      } catch (caughtError) {
        if (!isMounted) {
          return;
        }

        setError(
          caughtError instanceof Error
            ? caughtError.message
            : 'Не удалось подготовить форму добавления публикации.',
        );
      } finally {
        if (isMounted) {
          setIsBootLoading(false);
        }
      }
    }

    void loadInitialData();

    return () => {
      isMounted = false;
    };
  }, [isRoleAllowed]);

  const selectedWorkForm = useMemo(
    () => workForms.find((item) => item.value === form.workFormType) ?? null,
    [form.workFormType, workForms],
  );

  const category = useMemo(() => resolveCategory(selectedWorkForm), [selectedWorkForm]);

  const selectedPublicationTypeLabel = useMemo(() => {
    return (
      publicationTypes.find((item) => item.value === form.publicationTypeFlag)?.label ??
      'Тип публикации'
    );
  }, [form.publicationTypeFlag, publicationTypes]);

  useEffect(() => {
    if (!selectorMode) {
      return;
    }

    let isMounted = true;

    async function loadSelectorItems() {
      setSelectorLoading(true);

      try {
        if (selectorMode === 'journal') {
          const items = await searchAdminJournals(selectorQuery);
          if (isMounted) {
            setJournalResults(items);
          }
          return;
        }

        if (selectorMode === 'publisher') {
          const items = await searchAdminPublishers(selectorQuery);
          if (isMounted) {
            setPublisherResults(items);
          }
          return;
        }

        if (selectorMode === 'related') {
          const items = await searchAdminArticles(selectorQuery);
          if (isMounted) {
            setRelatedResults(items);
          }
        }
      } catch (caughtError) {
        if (isMounted) {
          setError(
            caughtError instanceof Error
              ? caughtError.message
              : 'Не удалось загрузить данные для выбора.',
          );
        }
      } finally {
        if (isMounted) {
          setSelectorLoading(false);
        }
      }
    }

    void loadSelectorItems();

    return () => {
      isMounted = false;
    };
  }, [selectorMode, selectorQuery]);

  const handleWorkFormChange = async (nextValue: string) => {
    setError('');
    setSuccessMessage('');
    setForm((prev) => ({
      ...prev,
      workFormType: nextValue,
      publicationTypeFlag: '',
      journal: null,
      publisher: null,
      relatedArticle: null,
      conferenceName: '',
    }));

    try {
      const items = await getAdminPublicationTypes(nextValue);
      setPublicationTypes(items);
      setForm((prev) => ({
        ...prev,
        publicationTypeFlag: items[0]?.value ?? '',
      }));
    } catch (caughtError) {
      setPublicationTypes([]);
      setError(
        caughtError instanceof Error
          ? caughtError.message
          : 'Не удалось загрузить типы публикаций.',
      );
    }
  };

  const openSelector = (mode: SelectorMode) => {
    setSelectorMode((prev) => (prev === mode ? null : mode));
    setSelectorQuery('');
  };

  const commitKeywordInput = () => {
    const nextKeywords = normalizeKeywords(form.keywordsInput);
    if (nextKeywords.length === 0) {
      setForm((prev) => ({
        ...prev,
        keywordsInput: '',
      }));
      return;
    }

    setForm((prev) => ({
      ...prev,
      keywords: normalizeKeywords([...prev.keywords, ...nextKeywords].join(',')),
      keywordsInput: '',
    }));
  };

  const removeKeyword = (keyword: string) => {
    setForm((prev) => ({
      ...prev,
      keywords: prev.keywords.filter((item) => item.toLowerCase() !== keyword.toLowerCase()),
    }));
  };

  const handleSubmit = async () => {
    setError('');
    setSuccessMessage('');

    const resolvedYear =
      form.year.trim() || (form.publicationDate ? form.publicationDate.slice(0, 4) : '');

    if (!form.title.trim()) {
      setError('Укажите название публикации.');
      return;
    }

    if (!resolvedYear || Number.isNaN(Number(resolvedYear))) {
      setError('Укажите год публикации или корректную дату публикации.');
      return;
    }

    const payload = {
      title: form.title.trim(),
      year: Number(resolvedYear),
      authors_text: form.authorsText.trim() || null,
      abstract: form.abstract.trim() || null,
      doi: form.doi.trim() || null,
      journal_id: form.journal?.id ?? null,
      edition: category === 'conference' ? form.conferenceName.trim() || null : null,
      work_form_type: form.workFormType || null,
      title_of_material: category === 'conference' ? form.conferenceName.trim() || null : null,
      publisher_id: form.publisher?.id ?? null,
      publication_date: form.publicationDate || null,
      pages: form.pages.trim() || null,
      extent_of_work: category === 'book' ? form.extentOfWork.trim() || null : null,
      url: category === 'conference' ? form.url.trim() || null : null,
      isbn: category === 'book' ? form.isbn.trim() || null : null,
      notes: category === 'book' ? form.notes.trim() || null : null,
      publication_type_flags: form.publicationTypeFlag ? [form.publicationTypeFlag] : [],
      keywords: form.keywords,
      original_version_id:
        form.relatedArticle && form.relatedRelationType === 'original'
          ? form.relatedArticle.id
          : null,
      translation_version_id:
        form.relatedArticle && form.relatedRelationType === 'translation'
          ? form.relatedArticle.id
          : null,
      tirage: category === 'book' ? form.tirage.trim() || null : null,
    };

    setIsSubmitting(true);

    try {
      const createdArticle = await createAdminArticle(payload);

      setSuccessMessage(`Публикация успешно добавлена. ID: ${createdArticle.id}`);
      setForm((prev) => ({
        ...INITIAL_FORM,
        workFormType: prev.workFormType,
        publicationTypeFlag: prev.publicationTypeFlag,
      }));
      setSelectorMode(null);
    } catch (caughtError) {
      setError(
        caughtError instanceof Error
          ? caughtError.message
          : 'Не удалось создать публикацию.',
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isInitializing || (isRoleAllowed && isBootLoading)) {
    return (
      <div className={styles.page}>
        <Header title="Добавить публикацию" />
        <main className={styles.main}>
          <div className="container">
            <div className={styles.loadingBox}>Загрузка формы…</div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!isRoleAllowed) {
    return (
      <div className={styles.page}>
        <Header title="Добавить публикацию" />
        <main className={styles.main}>
          <div className="container">
            <div className={styles.deniedBox}>
              Доступ к странице добавления публикаций разрешён только пользователям с ролью 5.
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <Header title="Добавить публикацию" />

      <main className={styles.main}>
        <div className="container">
          {error ? <div className={styles.errorBox}>{error}</div> : null}
          {successMessage ? <div className={styles.successBox}>{successMessage}</div> : null}

          <section className={styles.card}>
            <div className={styles.topRow}>
              <TextField
                label="Тип публикации"
                value={getWorkFormLabel(selectedWorkForm ?? { value: '', label: '', label_ru: '' })}
                readOnly
                onChange={() => undefined}
              />
              <TextField
                label="Подтип публикации"
                value={selectedPublicationTypeLabel}
                readOnly
                onChange={() => undefined}
              />
            </div>

            <div className={styles.topRow}>
              <div>
                <label className={styles.helperText} htmlFor="work-form-select">
                  Основной тип
                </label>
                <select
                  id="work-form-select"
                  className={styles.selectorValue}
                  value={form.workFormType}
                  onChange={(event) => void handleWorkFormChange(event.target.value)}
                >
                  {workForms.map((item) => (
                    <option key={item.value} value={item.value}>
                      {getWorkFormLabel(item)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={styles.helperText} htmlFor="publication-type-select">
                  Вид публикации
                </label>
                <select
                  id="publication-type-select"
                  className={styles.selectorValue}
                  value={form.publicationTypeFlag}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      publicationTypeFlag: event.target.value,
                    }))
                  }
                >
                  {publicationTypes.map((item) => (
                    <option key={item.value} value={item.value}>
                      {item.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className={styles.section}>
              <TextField
                label={
                  category === 'book'
                    ? 'Название монографии'
                    : category === 'conference'
                      ? 'Название материала'
                      : 'Название'
                }
                value={form.title}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    title: event.target.value,
                  }))
                }
              />

              <TextField
                label={
                  category === 'book'
                    ? 'Авторы монографии'
                    : category === 'conference'
                      ? 'Авторы материала'
                      : 'Авторы'
                }
                value={form.authorsText}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    authorsText: event.target.value,
                  }))
                }
                supportingText="В текущем бэке создание публикации использует строковое поле authors_text."
              />
            </div>

            {category === 'article' ? (
              <div className={styles.section}>
                <div className={styles.sectionTitle}>Издание</div>
                <div className={styles.selectorBox}>
                  <div className={styles.selectorTrigger}>
                    <div className={styles.selectorValue}>
                      {form.journal ? (
                        form.journal.label
                      ) : (
                        <span className={styles.selectorPlaceholder}>Журнал не выбран</span>
                      )}
                    </div>
                    <Button
                      label={selectorMode === 'journal' ? 'Скрыть' : 'Выбрать'}
                      size="normal"
                      onClick={() => openSelector('journal')}
                    />
                  </div>

                  {selectorMode === 'journal' ? (
                    <div className={styles.selectorPanel}>
                      <TextField
                        label="Поиск журнала"
                        value={selectorQuery}
                        onChange={(event) => setSelectorQuery(event.target.value)}
                      />
                      <div className={styles.selectorResults}>
                        {selectorLoading ? <div className={styles.helperText}>Загрузка…</div> : null}
                        {!selectorLoading && journalResults.length === 0 ? (
                          <div className={styles.helperText}>Совпадения не найдены.</div>
                        ) : null}
                        {journalResults.map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            className={styles.selectorItem}
                            onClick={() => {
                              setForm((prev) => ({ ...prev, journal: item }));
                              setSelectorMode(null);
                            }}
                          >
                            <div className={styles.selectorItemTitle}>{item.label}</div>
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>
            ) : null}

            {category === 'conference' ? (
              <div className={styles.section}>
                <TextField
                  label="Конференция"
                  value={form.conferenceName}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      conferenceName: event.target.value,
                    }))
                  }
                  supportingText="В текущем бэке название конференции сохраняется в полях edition и title_of_material."
                />
              </div>
            ) : null}

            {(category === 'book' || category === 'conference') ? (
              <div className={styles.section}>
                <div className={styles.sectionTitle}>Издательство</div>
                <div className={styles.selectorBox}>
                  <div className={styles.selectorTrigger}>
                    <div className={styles.selectorValue}>
                      {form.publisher ? (
                        form.publisher.label
                      ) : (
                        <span className={styles.selectorPlaceholder}>Издательство не выбрано</span>
                      )}
                    </div>
                    <Button
                      label={selectorMode === 'publisher' ? 'Скрыть' : 'Выбрать'}
                      size="normal"
                      onClick={() => openSelector('publisher')}
                    />
                  </div>

                  {selectorMode === 'publisher' ? (
                    <div className={styles.selectorPanel}>
                      <TextField
                        label="Поиск издательства"
                        value={selectorQuery}
                        onChange={(event) => setSelectorQuery(event.target.value)}
                      />
                      <div className={styles.selectorResults}>
                        {selectorLoading ? <div className={styles.helperText}>Загрузка…</div> : null}
                        {!selectorLoading && publisherResults.length === 0 ? (
                          <div className={styles.helperText}>Совпадения не найдены.</div>
                        ) : null}
                        {publisherResults.map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            className={styles.selectorItem}
                            onClick={() => {
                              setForm((prev) => ({ ...prev, publisher: item }));
                              setSelectorMode(null);
                            }}
                          >
                            <div className={styles.selectorItemTitle}>{item.label}</div>
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>
            ) : null}

            <div className={category === 'book' ? styles.gridThree : styles.gridTwo}>
              {category === 'book' ? (
                <TextField
                  label="ISBN"
                  value={form.isbn}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      isbn: event.target.value,
                    }))
                  }
                />
              ) : null}

              <TextField
                label="DOI"
                value={form.doi}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    doi: event.target.value,
                  }))
                }
              />

              {category === 'conference' ? (
                <TextField
                  label="URL"
                  value={form.url}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      url: event.target.value,
                    }))
                  }
                />
              ) : null}

              {category !== 'book' ? (
                <TextField
                  label="Страницы"
                  value={form.pages}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      pages: event.target.value,
                    }))
                  }
                />
              ) : null}

              <TextField
                label={category === 'book' ? 'Год' : 'Дата публикации'}
                type={category === 'book' ? 'number' : 'date'}
                value={category === 'book' ? form.year : form.publicationDate}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    [category === 'book' ? 'year' : 'publicationDate']: event.target.value,
                  }))
                }
                supportingText={
                  category === 'book'
                    ? undefined
                    : 'Год будет автоматически взят из даты, если отдельное поле года не заполнено.'
                }
              />

              {category === 'book' ? (
                <>
                  <TextField
                    label="Тираж"
                    value={form.tirage}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        tirage: event.target.value,
                      }))
                    }
                  />
                  <TextField
                    label="Объём работы"
                    value={form.extentOfWork}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        extentOfWork: event.target.value,
                      }))
                    }
                  />
                </>
              ) : null}
            </div>

            {category !== 'book' ? (
              <div className={styles.gridTwo}>
                <TextField
                  label="Год публикации"
                  type="number"
                  value={form.year}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      year: event.target.value,
                    }))
                  }
                />
                <div />
              </div>
            ) : null}

            {category === 'book' ? (
              <TextField
                label="Редакция"
                value={form.notes}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    notes: event.target.value,
                  }))
                }
              />
            ) : null}

            <div className={styles.textareaWrap}>
              <label className={styles.textareaLabel} htmlFor="abstract-field">
                Аннотация
              </label>
              <textarea
                id="abstract-field"
                className={styles.textareaField}
                value={form.abstract}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    abstract: event.target.value,
                  }))
                }
              />
            </div>

            <div className={styles.section}>
              <div className={styles.sectionTitle}>Ключевые слова</div>
              <div className={styles.keywordsBox}>
                <TextField
                  label="Ключевые слова через запятую"
                  value={form.keywordsInput}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      keywordsInput: event.target.value,
                    }))
                  }
                  onBlur={commitKeywordInput}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter') {
                      event.preventDefault();
                      commitKeywordInput();
                    }
                  }}
                />
                {form.keywords.length > 0 ? (
                  <div className={styles.chips}>
                    {form.keywords.map((keyword) => (
                      <span key={keyword} className={styles.chip}>
                        {keyword}
                        <button
                          type="button"
                          className={styles.chipRemove}
                          onClick={() => removeKeyword(keyword)}
                          aria-label={`Удалить ${keyword}`}
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                ) : null}
              </div>
            </div>

            <div className={styles.pdfStub}>
              <div className={styles.pdfField}>
                Файл PDF — загрузка пока не поддерживается текущим бэком
              </div>
              <OutlineButton label="Обзор" size="normal" disabled />
            </div>

            {category === 'article' ? (
              <div className={styles.section}>
                <div className={styles.gridTwo}>
                  <div>
                    <label className={styles.helperText} htmlFor="related-type-select">
                      Тип связи
                    </label>
                    <select
                      id="related-type-select"
                      className={styles.selectorValue}
                      value={form.relatedRelationType}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          relatedRelationType: event.target.value as RelatedRelationType,
                        }))
                      }
                    >
                      <option value="original">Оригинальная версия</option>
                      <option value="translation">Переводная версия</option>
                    </select>
                  </div>
                  <div className={styles.actions}>
                    <Button
                      label={selectorMode === 'related' ? 'Скрыть поиск' : 'Выбрать связанную статью'}
                      size="normal"
                      onClick={() => openSelector('related')}
                    />
                  </div>
                </div>

                {selectorMode === 'related' ? (
                  <div className={styles.selectorPanel}>
                    <TextField
                      label="Поиск статьи"
                      value={selectorQuery}
                      onChange={(event) => setSelectorQuery(event.target.value)}
                    />
                    <div className={styles.selectorResults}>
                      {selectorLoading ? <div className={styles.helperText}>Загрузка…</div> : null}
                      {!selectorLoading && relatedResults.length === 0 ? (
                        <div className={styles.helperText}>Совпадения не найдены.</div>
                      ) : null}
                      {relatedResults.map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          className={styles.selectorItem}
                          onClick={() => {
                            setForm((prev) => ({ ...prev, relatedArticle: item }));
                            setSelectorMode(null);
                          }}
                        >
                          <div className={styles.selectorItemTitle}>
                            {item.title || `Статья #${item.id}`}
                          </div>
                          <div className={styles.selectorItemMeta}>{formatArticleMeta(item)}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                ) : null}

                {form.relatedArticle ? (
                  <div className={styles.relatedCard}>
                    <div className={styles.relatedTitle}>
                      {form.relatedArticle.title || `Статья #${form.relatedArticle.id}`}
                    </div>
                    <div className={styles.relatedMeta}>
                      {formatArticleMeta(form.relatedArticle)}
                    </div>
                    <div className={styles.actions}>
                      <OutlineButton
                        label="Удалить связь"
                        size="small"
                        onClick={() =>
                          setForm((prev) => ({
                            ...prev,
                            relatedArticle: null,
                          }))
                        }
                      />
                    </div>
                  </div>
                ) : null}
              </div>
            ) : null}

            <div className={styles.actions}>
              <OutlineButton
                label="Назад к публикациям"
                size="normal"
                onClick={() => navigateTo('/articles')}
              />
              <Button
                label={isSubmitting ? 'Сохранение...' : 'Сохранить публикацию'}
                size="normal"
                onClick={() => void handleSubmit()}
                disabled={isSubmitting}
              />
            </div>
          </section>
        </div>
      </main>

      <Footer />
    </div>
  );
}