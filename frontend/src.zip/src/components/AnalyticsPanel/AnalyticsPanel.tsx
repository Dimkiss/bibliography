import { useEffect, useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  getAnalyticsDashboard,
  type DashboardLwlPoint,
  type DashboardResponse,
  type DashboardTypePoint,
  type DashboardYearsPoint,
} from '@/shared/api/analytics';
import styles from './AnalyticsPanel.module.css';

type AnalyticsPanelProps = {
  defaultYearsFrom?: number;
  defaultYearsTo?: number;
  defaultTypesYear?: number;
  defaultLwlYear?: number;
};

const PIE_COLORS = [
  'var(--bkg)',
  'var(--button-tonal)',
  'var(--Vector)',
  'var(--Rectangle)',
  'var(--Ellipse-1)',
  'var(--Ellipse-2)',
];

const BAR_COLORS = [
  'var(--Value-indicator)',
  'var(--Rectangle-24)',
  'var(--Vector)',
  'var(--Ellipse-4)',
  'var(--Rectangle)',
];

export function AnalyticsPanel({
  defaultYearsFrom = 2020,
  defaultYearsTo = 2024,
  defaultTypesYear = 2024,
  defaultLwlYear = 2024,
}: AnalyticsPanelProps) {
  const [yearsFrom, setYearsFrom] = useState<number>(defaultYearsFrom);
  const [yearsTo, setYearsTo] = useState<number>(defaultYearsTo);
  const [typesYear, setTypesYear] = useState<number>(defaultTypesYear);
  const [lwlYear, setLwlYear] = useState<number>(defaultLwlYear);

  const [data, setData] = useState<DashboardResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    async function loadDashboard() {
      try {
        setIsLoading(true);
        setError(null);

        const response = await getAnalyticsDashboard({
          yearsFrom,
          yearsTo,
          typesYear,
          lwlYear,
        });

        if (!isMounted) {
          return;
        }

        setData(response);
      } catch {
        if (!isMounted) {
          return;
        }

        setError('Не удалось загрузить аналитическую панель');
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    }

    loadDashboard();

    return () => {
      isMounted = false;
    };
  }, [yearsFrom, yearsTo, typesYear, lwlYear]);

  const availableYears = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const startYear = 2000;
    return Array.from(
      { length: currentYear - startYear + 1 },
      (_, index) => currentYear - index,
    );
  }, []);

  return (
    <section className={styles.section} aria-labelledby="analytics-panel-title">
      <div className={styles.header}>
        <h2 id="analytics-panel-title" className={styles.title}>
          Аналитика публикаций
        </h2>
      </div>

      <div className={styles.filters}>
        <div className={styles.filterGroup}>
          <label className={styles.label}>
            Период с
            <select
              className={styles.select}
              value={yearsFrom}
              onChange={(event) => setYearsFrom(Number(event.target.value))}
            >
              {availableYears.map((year) => (
                <option key={`from-${year}`} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </label>

          <label className={styles.label}>
            по
            <select
              className={styles.select}
              value={yearsTo}
              onChange={(event) => setYearsTo(Number(event.target.value))}
            >
              {availableYears.map((year) => (
                <option key={`to-${year}`} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className={styles.filterGroup}>
          <label className={styles.label}>
            Типы за год
            <select
              className={styles.select}
              value={typesYear}
              onChange={(event) => setTypesYear(Number(event.target.value))}
            >
              {availableYears.map((year) => (
                <option key={`types-${year}`} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </label>

          <label className={styles.label}>
            Уровни за год
            <select
              className={styles.select}
              value={lwlYear}
              onChange={(event) => setLwlYear(Number(event.target.value))}
            >
              {availableYears.map((year) => (
                <option key={`lwl-${year}`} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>

      {isLoading && <div className={styles.state}>Загрузка аналитики...</div>}
      {!isLoading && error && <div className={styles.state}>{error}</div>}

      {!isLoading && !error && data && (
        <div className={styles.grid}>
          <AnalyticsYearsCard data={data.years.series} />
          <AnalyticsTypesCard
            year={data.types.year}
            total={data.types.total}
            data={data.types.series}
          />
          <AnalyticsLwlCard year={data.lwl.year} data={data.lwl.series} />
        </div>
      )}
    </section>
  );
}

type AnalyticsYearsCardProps = {
  data: DashboardYearsPoint[];
};

function AnalyticsYearsCard({ data }: AnalyticsYearsCardProps) {
  return (
    <article className={styles.card}>
      <div className={styles.cardHeader}>
        <h3 className={styles.cardTitle}>Публикации по годам</h3>
      </div>

      <div className={styles.chartWrap}>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={data}>
            <CartesianGrid stroke="var(--detail)" vertical={false} />
            <XAxis dataKey="year" tick={{ fontSize: 12, fill: '#444444' }} />
            <YAxis tick={{ fontSize: 12, fill: '#444444' }} />
            <Tooltip />
            <Bar dataKey="count" radius={[8, 8, 0, 0]} fill="var(--bkg)" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </article>
  );
}

type AnalyticsTypesCardProps = {
  year: number;
  total: number;
  data: DashboardTypePoint[];
};

function AnalyticsTypesCard({ year, total, data }: AnalyticsTypesCardProps) {
  return (
    <article className={styles.card}>
      <div className={styles.cardHeader}>
        <h3 className={styles.cardTitle}>Типы публикаций</h3>
        <div className={styles.cardSubtext}>
          {year} • Всего: {total}
        </div>
      </div>

      <div className={styles.chartWrap}>
        <ResponsiveContainer width="100%" height={280}>
          <PieChart>
            <Tooltip />
            <Pie
              data={data}
              dataKey="count"
              nameKey="category"
              cx="50%"
              cy="50%"
              outerRadius={90}
              innerRadius={45}
            >
              {data.map((entry, index) => (
                <Cell
                  key={`${entry.category}-${index}`}
                  fill={PIE_COLORS[index % PIE_COLORS.length]}
                />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className={styles.legend}>
        {data.map((item, index) => (
          <div key={item.category} className={styles.legendItem}>
            <span
              className={styles.legendDot}
              style={{ background: PIE_COLORS[index % PIE_COLORS.length] }}
            />
            <span className={styles.legendText}>
              {item.category}: {item.count}
            </span>
          </div>
        ))}
      </div>
    </article>
  );
}

type AnalyticsLwlCardProps = {
  year: number;
  data: DashboardLwlPoint[];
};

function AnalyticsLwlCard({ year, data }: AnalyticsLwlCardProps) {
  return (
    <article className={styles.card}>
      <div className={styles.cardHeader}>
        <h3 className={styles.cardTitle}>Распределение по УБС</h3>
        <div className={styles.cardSubtext}>{year}</div>
      </div>

      <div className={styles.chartWrap}>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={data} layout="vertical" margin={{ left: 16 }}>
            <CartesianGrid stroke="var(--detail)" horizontal={false} />
            <XAxis type="number" tick={{ fontSize: 12, fill: '#444444' }} />
            <YAxis
              type="category"
              dataKey="label"
              width={90}
              tick={{ fontSize: 12, fill: '#444444' }}
            />
            <Tooltip />
            <Bar dataKey="count" radius={[0, 8, 8, 0]}>
              {data.map((entry, index) => (
                <Cell
                  key={`${entry.label}-${entry.level}`}
                  fill={BAR_COLORS[index % BAR_COLORS.length]}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </article>
  );
}